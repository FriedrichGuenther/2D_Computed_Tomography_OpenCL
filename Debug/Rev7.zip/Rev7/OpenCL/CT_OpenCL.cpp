#define CL_HPP_TARGET_OPENCL_VERSION 120
#define CL_HPP_MINIMUM_OPENCL_VERSION 120
#define __CL_ENABLE_EXCEPTIONS // Allows for better error catching/handling
#if defined(__APPLE__)  // C++ Wrapper for OpenCL
#include <OpenCL/cl2.hpp>
#else 
#include <CL/cl2.hpp>
#endif
#include <iostream> // IO Streams (cout, cin, ...)
#include <fstream> // File streams
#include <vector> // Vectors
#include <string> // String library
#include <sstream> // Streams
#include <iomanip> // Output formating
#include <cmath> // Math functions
#include <random> // Random number generator
#include <chrono>
#include "CL_err_helper.hpp"

using namespace std;
using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::duration;
using std::chrono::milliseconds;

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------

// Function declarations

// Phantom
void raster_ellipse(vector<float>& image, int res, vector<float> focus, float semimajor, float semiminor, float gray_value);
void raster_ellipse_rotated(vector<float>& image, int res, vector<float> focus, float semimajor, float semiminor, float gray_value, float angle);
vector<float> raster_shepp_logan(unsigned int res);

// OpenCL host functions
void set_up_platform_and_devices(cl::Platform& cpu_platform, cl::Device& cpu_device);
cl::Program CL_create_program_source(cl::Context context, string filename);

// Buffer-Crunchers
vector<float> CL_compute_sinogram(cl::Device device, cl::Context context, vector<float>& phantom, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_fast_ram_lak_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans); 
vector<float> CL_fast_shepp_logan_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_fast_cosine_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_discrete_back_projection(cl::Device device, cl::Context context, vector<float> &sinogram, unsigned int res, unsigned int rots, unsigned int scans);
// Slow filters for regularisation and comparison
vector<float> CL_ram_lak_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_shepp_logan_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_cosine_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans);

// Image-Crunchers
vector<float> CL_compute_sinogram_img(cl::Device device, cl::Context context, vector<float>& phantom_img, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_fast_ram_lak_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans); 
vector<float> CL_fast_shepp_logan_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_fast_cosine_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_discrete_back_projection_img(cl::Device device, cl::Context context, vector<float> &sinogram_img, unsigned int res, unsigned int rots, unsigned int scans);
// Slow filters for regularisation and comparision
vector<float> CL_ram_lak_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_shepp_logan_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> CL_cosine_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans);

// Miscellaneous for buffer <-> image2d_t
vector<float> create_image2d_type(vector<float>& image);
vector<float> reduce_to_buffer(vector<float>& image);
void remove_artifacts(vector<float>& reconstruction, unsigned int res);

// Execution functions
vector<duration<double, std::milli>> bench_for_execution_time(vector<float> (*crunch)(cl::Device, cl::Context, vector<float>&, unsigned int, unsigned int, unsigned int), unsigned int iterations, cl::Device device, cl::Context context, vector<float>& image, unsigned int res, unsigned int rots, unsigned int scans);
vector<float> run_function(vector<float> (*crunch)(cl::Device, cl::Context, vector<float>&, unsigned int, unsigned int, unsigned int), cl::Device device, cl::Context context, vector<float>& image, unsigned int res, unsigned int rots, unsigned int scans);
// Benchmark and image producers
void run_benchmark(vector<float>& phantom, unsigned int iterations, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);
void produce_images(vector<float>& phantom, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);
void noisy_data(vector<float>& phantom, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);

void run_benchmark_img(vector<float>& phantom_img, unsigned int iterations, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);
void produce_images_img(vector<float>& phantom_img, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);
void noisy_data_img(vector<float>& phantom_img, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans);

// CT functions
unsigned int set_resolution(unsigned int m, unsigned int n);
vector<float> salt_and_pepper_noise(unsigned int res, float amp);
vector<float> add_matrices(vector<float>& A, vector<float>& B);
vector<float> subtract_matrices(vector<float>& A, vector<float>& B);
vector<float> absolute_value_of_matrix_difference(vector<float>& A, vector<float>& B);

// IO functions and miscellaneous
bool try_reading_float(string& input, float& output);
bool try_reading_uint(string& input, unsigned int& output);
void split_string(string& input, vector<string>& output);
void print_matrix_float(vector<float> matrix, const unsigned int& m, const unsigned int& n);
void write_matrix_float_to_file(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n);
void write_matrix_float_to_pgm(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n);
void write_matrix_float_to_pgm_normalised(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n);
vector<float> read_matrix_float(string filename, unsigned int& m, unsigned int& n);
vector<float> read_pgm_to_matrix_float(string filename, unsigned int& m, unsigned int& n);

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------


int main(void)
{
	try // OpenCL host
	{
		// Setting up GPU platform and device
		cl::Platform platform;
		cl::Device device;
		set_up_platform_and_devices(platform, device);
		cl::Context context(device);
		
		// Constants 
		vector<unsigned int> resolutions = {64,128,256,512,1024,2048,4096};
		unsigned int res,m,n,rots,scans,underscans,iterations;
		bool use_buffers = true;
		
		for(int i=0; i<resolutions.size(); i++)
		{
			res = resolutions[i];
			
			rots = res;
			underscans = 1;
			scans = res/underscans;
			iterations = 5;
			
			cout << "Rastering Shepp-Logan phantom..." << endl;
			vector<float> phantom = raster_shepp_logan(res);
			cout << "Working on Shepp-Logan phantom in "<< res << "x" << res << " pixels..." << endl;
			
			if(use_buffers)
			{
				run_benchmark(phantom, iterations, device, context, res, rots, scans);
				// produce_images(phantom, device, context, res, rots, scans);
				// noisy_data(phantom, device, context, res, rots, scans);
			}
		
			if(use_buffers) // At some point, one could use this switch
			{
				vector<float> phantom_img = create_image2d_type(phantom);
				run_benchmark_img(phantom_img, iterations, device, context, res, rots, scans);
				// produce_images_img(phantom_img, device, context, res, rots, scans);
				// noisy_data_img(phantom_img, device, context, res, rots, scans);
			}
		}	
		
		return EXIT_SUCCESS;
	} 
	catch(const cl::Error& clExp) 
	{
		cout << "CL Exception: " << clExp.what() << " with error code " << opencl_err_to_str(clExp.err()) << " (" << clExp.err() << ")" << endl;
	} 
	catch(const std::exception& e) 
	{
		cout << "Other exception: " << e.what() << endl;
	}
}

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------

// --------------------------------------------------------------------------------------------------------------------------------
// OpenCL Host
// --------------------------------------------------------------------------------------------------------------------------------

void set_up_platform_and_devices(cl::Platform& cpu_platform, cl::Device& cpu_device)
{
	vector<cl::Platform> platforms;
	vector<cl::Device> devices_per_platform;
	vector<cl::Device> gpu_devices;
	
	unsigned int num_platforms;
	unsigned int num_target_device=0;
	unsigned int num_devices;
	unsigned int total_gpus;
	string input;
	
	cl::Platform::get(&platforms);
	num_platforms = platforms.size();
	
	for(int i=0; i<num_platforms; i++)
	{
		platforms[i].getDevices(CL_DEVICE_TYPE_ALL, &devices_per_platform);
		num_devices = devices_per_platform.size();
		for(int j=0; j<num_devices; j++)
		{
			if(devices_per_platform[j].getInfo<CL_DEVICE_TYPE>() == CL_DEVICE_TYPE_GPU)
			{
				gpu_devices.push_back(devices_per_platform[j]);
			}
			devices_per_platform.clear();
		}
	}
	total_gpus = gpu_devices.size();
	
	if(total_gpus == 0) 
	{
		throw std::runtime_error("No GPU devices available! Cannot carry on.");
	}

	if(total_gpus == 1)
	{
		cpu_device = gpu_devices[0];
		cpu_platform = gpu_devices[0].getInfo<CL_DEVICE_PLATFORM>();
		cout << "Selected " << cpu_device.getInfo<CL_DEVICE_NAME>() << " on platform " << cpu_platform.getInfo<CL_PLATFORM_NAME>() << " as GPU device." << endl;
	}
	
	if(total_gpus > 1)
	{
		cout << "Available GPU devices: " << endl;
		for(int i=0; i<total_gpus; i++)
		{
			cout << "["<<i+1<<"] " << gpu_devices[i].getInfo<CL_DEVICE_NAME>() << endl;
		}
		cout << "Please enter target GPU device: ";
		getline(cin, input); 
		while(!try_reading_uint(input, num_target_device) or num_target_device < 1 or num_target_device > total_gpus)
		{	
			cout << "Please enter target GPU device: ";
			getline(cin, input);
		}
		num_target_device--;
		cpu_device = gpu_devices[num_target_device];
		cpu_platform = cpu_device.getInfo<CL_DEVICE_PLATFORM>();
		cout << "Selected " << cpu_device.getInfo<CL_DEVICE_NAME>() << " on platform " << cpu_platform.getInfo<CL_PLATFORM_NAME>() << " as GPU device." << endl;
		num_target_device=0;
		cin.clear();
	}
	
}

cl::Program CL_create_program_from_source(cl::Context context, cl::Device device, string filename)
{
	ifstream program_file(filename);
	string program_string(istreambuf_iterator<char>(program_file), (istreambuf_iterator<char>()));
	cl::Program::Sources source { program_string };
	cl::Program program(context, source);
	try
	{
		program.build();
	}
	catch(cl::Error e)
	{
		cout << e.what() << " ; Error code " << e.err() << endl;
		string build_log;
		build_log = program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(device);
		cout << build_log << endl;
	}
	
	return program;
}

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// Buffer crunchers
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------

vector<float> CL_compute_sinogram(cl::Device device, cl::Context context, vector<float>& image, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> rotated(rots*res, 0.0);
	vector<float> sinogram(rots*scans, 0.0);
	vector<int> scales(res, 0.0);
	
	int underscans = res/scans;
	float h = (float) 2/res;	
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/compute_sinogram.cl");
	cl::Kernel kernel(program, "compute_sinogram");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Image(context, CL_MEM_READ_ONLY, res*res*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Sinogram(context, CL_MEM_WRITE_ONLY, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Image, CL_TRUE, 0, res*res*sizeof(float), &image[0]);
	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Image);
	kernel.setArg(1, Sinogram);
	kernel.setArg(2, res);
	kernel.setArg(3, scans);
	kernel.setArg(4, underscans);
	kernel.setArg(5, rots);
	kernel.setArg(6, pi);
	kernel.setArg(7, h);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NullRange, NULL); // cl::NDRange(16,16)
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL); // cl::NDRange(16,16)
	queue.enqueueReadBuffer(Sinogram, CL_TRUE, 0, scans*rots*sizeof(float), &sinogram[0]);
	queue.finish();
	
	return sinogram;
}

// Fast filters
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_fast_ram_lak_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_ram_lak_filter.cl");
	cl::Kernel kernel(program, "fast_ram_lak_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);

	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NullRange, NULL); // cl::NDRange(16,16)
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	
	return filtered;
}

vector<float> CL_fast_shepp_logan_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_shepp_logan_filter.cl");
	cl::Kernel kernel(program, "fast_shepp_logan_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);

	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	return filtered;
}

vector<float> CL_fast_cosine_filter(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_cosine_filter.cl");
	cl::Kernel kernel(program, "fast_cosine_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	return filtered;
}

// Discrete Backprojection
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_discrete_back_projection(cl::Device device, cl::Context context, vector<float>& sinogram, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> reconstruction(res*res, 0.0);
	float h = (float) 2/res;
	float pi = 4*atan(1);
	float scale = (float) 2*pi/rots;
	int half_scans=scans/2;
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/discrete_back_projection.cl");
	cl::Kernel kernel(program, "discrete_back_projection");
	cl::CommandQueue queue(context, device, CL_QUEUE_PROFILING_ENABLE);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // |CL_MEM_ALLOC_HOST_PTR Pinned host memory for a little extra speed
	cl::Buffer Reconstruction(context, CL_MEM_READ_WRITE, res*res*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	queue.enqueueWriteBuffer(Reconstruction, CL_TRUE, 0, res*res*sizeof(float), &reconstruction[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Reconstruction);
	kernel.setArg(2, res);
	kernel.setArg(3, half_scans);
	kernel.setArg(4, scans);
	kernel.setArg(5, rots);
	kernel.setArg(6, scale);
	kernel.setArg(7, pi);
	kernel.setArg(8, h);

	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(res, res), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Reconstruction, CL_TRUE, 0, res*res*sizeof(float), &reconstruction[0]);
	queue.finish();
	
	return reconstruction;
}

// Slow filters
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_ram_lak_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/ram_lak_filter.cl");
	cl::Kernel kernel(program, "ram_lak_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	return filtered;
}

vector<float> CL_shepp_logan_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/shepp_logan_filter.cl");
	cl::Kernel kernel(program, "shepp_logan_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	return filtered;
}

vector<float> CL_cosine_filter(cl::Device device, cl::Context context, vector<float>& sinogram, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered(rots*scans, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/cosine_filter.cl");
	cl::Kernel kernel(program, "cosine_filter");
	cl::CommandQueue queue(context, device);
	
	cl::Buffer Sinogram(context, CL_MEM_READ_ONLY, rots*scans*sizeof(float)); // Pinned host memory for a little extra speed
	cl::Buffer Filtered(context, CL_MEM_READ_WRITE, rots*scans*sizeof(float));

	queue.enqueueWriteBuffer(Sinogram, CL_TRUE, 0, rots*scans*sizeof(float), &sinogram[0]);
	
	kernel.setArg(0, Sinogram);
	kernel.setArg(1, Filtered);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Filtered, CL_TRUE, 0, rots*scans*sizeof(float), &filtered[0]);
	queue.finish();
	
	return filtered;
}

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// Image crunchers
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------


// Sinogram
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_compute_sinogram_img(cl::Device device, cl::Context context, vector<float>& phantom_img, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> sinogram_img(rots*scans*4, 0.0);
	
	int underscans = res/scans;
	float h = (float) 2/res;	
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/compute_sinogram_img.cl");
	cl::Kernel kernel(program, "compute_sinogram");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Phantom_Image(context, CL_MEM_READ_ONLY, rgb, res, res);
	cl::Image2D Sinogram_Image(context, CL_MEM_WRITE_ONLY, rgb, scans, rots);
	
	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {res, res, 1};
	std::array<cl::size_type, 3> region_dst {scans, rots, 1};

	queue.enqueueWriteImage(Phantom_Image, CL_TRUE, origin, region, 0, 0, &phantom_img[0]);
	
	kernel.setArg(0, Phantom_Image);
	kernel.setArg(1, Sinogram_Image);
	kernel.setArg(2, res);
	kernel.setArg(3, scans);
	kernel.setArg(4, underscans);
	kernel.setArg(5, rots);
	kernel.setArg(6, pi);
	kernel.setArg(7, h);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NullRange, NULL); // cl::NDRange(16,16)
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadImage(Sinogram_Image, CL_TRUE, origin, region_dst, 0, 0, &sinogram_img[0]);
	queue.finish();
	
	return sinogram_img;
}

// Fast filters
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_fast_ram_lak_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_ram_lak_filter_img.cl");
	cl::Kernel kernel(program, "fast_ram_lak_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);

	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); // cl::NDRange(16,16)
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

vector<float> CL_fast_shepp_logan_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_shepp_logan_filter_img.cl");
	cl::Kernel kernel(program, "fast_shepp_logan_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);

	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

vector<float> CL_fast_cosine_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/fast_cosine_filter_img.cl");
	cl::Kernel kernel(program, "fast_cosine_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

// Back projection
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_discrete_back_projection_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> reconstruction(res*res, 0.0);
	
	float h = (float) 2/res;
	float pi = 4*atan(1);
	float scale = (float) 2*pi/rots;
	int half_scans=scans/2;
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/discrete_back_projection_img.cl");
	cl::Kernel kernel(program, "discrete_back_projection");
	cl::CommandQueue queue(context, device, CL_QUEUE_PROFILING_ENABLE);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Buffer Reconstruction(context, CL_MEM_READ_WRITE, res*res*sizeof(float));

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	queue.enqueueWriteBuffer(Reconstruction, CL_TRUE, 0, res*res*sizeof(float), &reconstruction[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Reconstruction);
	kernel.setArg(2, res);
	kernel.setArg(3, half_scans);
	kernel.setArg(4, scans);
	kernel.setArg(5, rots);
	kernel.setArg(6, scale);
	kernel.setArg(7, pi);
	kernel.setArg(8, h);
	
	//queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(res, res), cl::NullRange, NULL); 
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(scans, rots), cl::NDRange(16,16), NULL);
	queue.enqueueReadBuffer(Reconstruction, CL_TRUE, 0, res*res*sizeof(float), &reconstruction[0]);
	queue.finish();
	
	return reconstruction;
}


// Slow filters
// --------------------------------------------------------------------------------------------------------------------------------
//

vector<float> CL_ram_lak_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/ram_lak_filter_img.cl");
	cl::Kernel kernel(program, "ram_lak_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);

	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); // cl::NDRange(16,16)
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

vector<float> CL_shepp_logan_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/shepp_logan_filter_img.cl");
	cl::Kernel kernel(program, "shepp_logan_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);

	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

vector<float> CL_cosine_filter_img(cl::Device device, cl::Context context, vector<float>& sinogram_img, float b, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> filtered_img(rots*scans*4, 0.0);
	
	float h = (float) 2/scans;
	float pi = 4*atan(1);
	float epsilon = pow(10,-8);
	
	cl::Program program = CL_create_program_from_source(context, device, "./Kernels/cosine_filter_img.cl");
	cl::Kernel kernel(program, "cosine_filter");
	cl::CommandQueue queue(context, device);
	
	cl::ImageFormat rgb(CL_RGBA, CL_FLOAT);
	cl::Image2D Sinogram_Image(context, CL_MEM_READ_ONLY, rgb, scans, rots);
	cl::Image2D Filtered_Image(context, CL_MEM_READ_WRITE, rgb, scans, rots);

	std::array<cl::size_type, 3> origin {0,0,0};
	std::array<cl::size_type, 3> region {scans, rots, 1};

	queue.enqueueWriteImage(Sinogram_Image, CL_TRUE, origin, region, 0, 0, &sinogram_img[0]);
	
	kernel.setArg(0, Sinogram_Image);
	kernel.setArg(1, Filtered_Image);
	kernel.setArg(2, scans);
	kernel.setArg(3, rots);
	kernel.setArg(4, pi);
	kernel.setArg(5, h);
	kernel.setArg(6, epsilon);
	kernel.setArg(7, b);
	
	queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(rots, scans), cl::NullRange, NULL); 
	queue.enqueueReadImage(Filtered_Image, CL_TRUE, origin, region, 0, 0, &filtered_img[0]);
	queue.finish();
	
	return filtered_img;
}

// --------------------------------------------------------------------------------------------------------------------------------
// Miscellaneous for buffer <-> image2d_t
// --------------------------------------------------------------------------------------------------------------------------------

vector<float> create_image2d_type(vector<float>& image)
{
	int k = image.size();
	vector<float> image_img(k*4, 0.0);
	for(int i=0; i<k; i++)
	{
		image_img[4*i] = image[i];
	}
	
	return image_img;
}

vector<float> reduce_to_buffer(vector<float>& image)
{
	int k = image.size();
	if ( (k&3) == 0)
	{
		int j = k/4;
		vector<float> output(j, 0.0);
		for(int i=0; i<j; i++)
		{
			output[i] = image[4*i];
		}
		return output;
	}
	else 
	{
		cout << "Corrupt image in >>reduce_to_buffer<<!" << endl;
		exit(-1);	
	}
}

void remove_artifacts(vector<float>& reconstruction, unsigned int res)
{
	for(int i=0; i<res; i++)
	{
		for(int j=0; j<res; j++)
		{
			if( sqrt( (i-res/2)*(i-res/2) + (j-res/2)*(j-res/2) ) > res/2)
			{
				reconstruction[i*res+j] = 0;
			}
		}
	}
}

// --------------------------------------------------------------------------------------------------------------------------------
// Execution functions
// --------------------------------------------------------------------------------------------------------------------------------


vector<duration<double, std::milli>> bench_for_execution_time(vector<float> (*crunch)(cl::Device, cl::Context, vector<float>& , unsigned int, unsigned int, unsigned int), unsigned int iterations, cl::Device device, cl::Context context, vector<float>& image, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<duration<double, std::milli>> times(3); // Total duration, average, standard deviation 
	vector<duration<double, std::milli>> individual_runs(iterations);
	vector<float> dummy;
	double standard_deviation=0;
	
	auto t1 = high_resolution_clock::now();
	auto t2 = high_resolution_clock::now();
	times[0] = t1-t1; // Set first component to zero
	for(int i=0; i<iterations; i++)
	{
		t1 = high_resolution_clock::now();
		dummy = crunch(device, context, image, res, rots, scans);
		t2 = high_resolution_clock::now();
		times[0] += t2-t1;
		individual_runs[i] = t2-t1;
	}
	times[1] = duration<double, std::milli>(times[0].count()/iterations);
	for(int i=0; i<iterations; i++)
	{
		standard_deviation += (individual_runs[i].count() - times[1].count())*(individual_runs[i].count() - times[1].count());
	}
	standard_deviation *= (double) 1/iterations;
	standard_deviation = sqrt(standard_deviation);
	times[2] = duration<double, std::milli>(standard_deviation);
	
	return times;
}

vector<float> run_function(vector<float> (*crunch)(cl::Device, cl::Context, vector<float>&, unsigned int, unsigned int, unsigned int), cl::Device device, cl::Context context, vector<float>& image, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<float> output;
	output = crunch(device, context, image, res, rots, scans);
	return output;
}

void run_benchmark(vector<float>& phantom, unsigned int iterations, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<duration<double, std::milli>> times;
	vector<float> sinogram;
	
	cout << "Running benchmark using buffers..." << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "| Function                        | total [ms] | avg [ms] | stdev [ms] |  N |" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout.precision(2);
	cout << fixed;
		
	auto function = CL_compute_sinogram;
	times = bench_for_execution_time(function, iterations, device, context, phantom, res, rots, scans);
	cout << right << "| CL_compute_sinogram             | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
	
	if(rots*scans != res*res)
	{	
		phantom = CL_compute_sinogram(device, context, phantom, res, rots, scans);
	}
	
	function = CL_fast_ram_lak_filter;
	times = bench_for_execution_time(function, iterations, device, context, phantom, res, rots, scans);
	cout << right << "| CL_fast_ram_lak_filter          | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_fast_shepp_logan_filter;
	times = bench_for_execution_time(function, iterations, device, context, phantom, res, rots, scans);
	cout << right << "| CL_fast_shepp_logan_filter      | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_fast_cosine_filter;
	times = bench_for_execution_time(function, iterations, device, context, phantom, res, rots, scans);
	cout << right << "| CL_fast_cosine_filter           | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_discrete_back_projection;
	times = bench_for_execution_time(function, iterations, device, context, phantom, res, rots, scans);
	cout << right << "| CL_discrete_back_projection     | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
}

void produce_images(vector<float>& phantom, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{	
	auto function = CL_compute_sinogram;
	vector<float> sinogram = run_function(function, device, context, phantom, res, rots, scans);
	cout << "Computed sinogram..." << endl;
		
	function = CL_fast_ram_lak_filter;
	vector<float> rlf = run_function(function, device, context, sinogram, res, rots, scans);
	cout << "Filtered sinogram with fast Ram-Lak filter..." << endl;
		
	function = CL_fast_shepp_logan_filter;
	vector<float> slf = run_function(function, device, context, sinogram, res, rots, scans);
	cout << "Filtered sinogram with fast Shepp-Logan filter..." << endl;
		
	function = CL_fast_cosine_filter;
	vector<float> cf = run_function(function, device, context, sinogram, res, rots, scans);
	cout << "Filtered sinogram with fast Cosine filter in ..." << endl;
		
	function = CL_discrete_back_projection; // Attention: Discrete back projection returns buffer, not image2d_t!
	vector<float> dbp = run_function(function, device, context, sinogram, res, rots, scans);
	cout << "Performed back projection of sinogram..." << endl;
		
	vector<float> dbp_rlf = run_function(function, device, context, rlf, res, rots, scans);
	cout << "Performed back projection of Ram-Lak filtered sinogram..." << endl;
		
	vector<float> dbp_slf = run_function(function, device, context, slf, res, rots, scans);
	cout << "Performed back projection of Shepp-Logan filtered sinogram..." << endl;
		
	function = CL_discrete_back_projection;
	vector<float> dbp_cf = run_function(function, device, context, cf, res, rots, scans);
	cout << "Performed back projection of Cosine filtered sinogram... " << endl; 
	
	remove_artifacts(dbp_rlf, res);
	remove_artifacts(dbp_slf, res);
	remove_artifacts(dbp_cf, res);
	vector<float> err_dbp = absolute_value_of_matrix_difference(phantom, dbp);
	vector<float> err_dbp_rlf = absolute_value_of_matrix_difference(phantom, dbp_rlf);
	vector<float> err_dbp_slf = absolute_value_of_matrix_difference(phantom, dbp_slf);
	vector<float> err_dbp_cf = absolute_value_of_matrix_difference(phantom, dbp_cf);
	
	string outfile = "./Output/sinogram_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm(outfile, sinogram, scans, rots);
		
	outfile = "./Output/sinogram_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, rlf, scans, rots);
	outfile = "./Output/sinogram_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, slf, scans, rots);
	outfile = "./Output/sinogram_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, cf, scans, rots);
	
	
	outfile = "./Output/dbp_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp, res, res);
	outfile = "./Output/dbp_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_rlf, res, res);
	outfile = "./Output/dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_slf, res, res);
	outfile = "./Output/dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_cf, res, res);
	
	
	outfile = "./Output/err_dbp_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp, res, res);
	outfile = "./Output/err_dbp_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_rlf, res, res);
	outfile = "./Output/err_dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_slf, res, res);
	outfile = "./Output/err_dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_cf, res, res);
	
	cout << "Wrote results to disk." << endl;
}

void noisy_data(vector<float>& phantom, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{
	float pi = 4*atan(1);
	float h = (float) 2/res;
	
	vector<float> sinogram_standard = CL_compute_sinogram(device, context, phantom, res, rots, scans);
	cout << "Computed sinogram..." << endl;
	
	vector<float> salt_and_pepper = salt_and_pepper_noise(res, 0.4);
	vector<float> sinogram = add_matrices(sinogram_standard, salt_and_pepper);
	
	write_matrix_float_to_pgm_normalised("phantom.pgm", phantom, res, res);
	write_matrix_float_to_pgm_normalised("sinogram_standard.pgm", sinogram, res, res);
	
	for(int i=0; i<3; i++)
	{
		vector<float> slf = CL_shepp_logan_filter(device, context, sinogram, pi/(3*(2*i+1)*h), res, rots, scans); 
		cout << "Computed Shepp-Logan filter..." << endl;
		vector<float> cf = CL_cosine_filter(device, context, sinogram, pi/(3*(2*i+1)*h), res, rots, scans); 
		cout << "Computed Cosine filter..." << endl;
		vector<float> dbp_slf = CL_discrete_back_projection(device, context, slf, res, rots, scans);
		cout << "Discrete back projection of Shepp-Logan filtered sinogram performed..." << endl;
		vector<float> dbp_cf = CL_discrete_back_projection(device, context, cf, res, rots, scans);
		cout << "Discrete back projection of Cosine filtered sinogram performed..." << endl;
	
		string outfile = "./Output/sinogram_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, slf, scans, rots);
		outfile = "./Output/sinogram_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, cf, scans, rots);
	
		remove_artifacts(dbp_slf, res);
		remove_artifacts(dbp_cf, res);
	
		outfile = "./Output/dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, dbp_slf, res, res);
		outfile = "./Output/dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, dbp_cf, res, res);
		cout << "Results written to disk." << endl;
		
		vector<float> difference = absolute_value_of_matrix_difference(dbp_slf, dbp_cf);
		outfile = "./Output/difference_cf_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, difference, res, res);
	}
}

// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// Image execution
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------
// --------------------------------------------------------------------------------------------------------------------------------



void run_benchmark_img(vector<float>& phantom_img, unsigned int iterations, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{
	vector<duration<double, std::milli>> times;
	vector<float> sinogram_img;
	
	cout << "Running benchmark using image2d_t's..." << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "| Function                        | total [ms] | avg [ms] | stdev [ms] |  N |" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout.precision(2);
	cout << fixed;
		
	auto function = CL_compute_sinogram_img;
	times = bench_for_execution_time(function, iterations, device, context, phantom_img, res, rots, scans);
	cout << right << "| CL_compute_sinogram_img         | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
	
	if (rots * scans != res*res)
	{
		phantom_img = CL_compute_sinogram(device, context, phantom_img, res, rots, scans);
	}
		
	function = CL_fast_ram_lak_filter_img;
	times = bench_for_execution_time(function, iterations, device, context, phantom_img, res, rots, scans);
	cout << right << "| CL_fast_ram_lak_filter_img      | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_fast_shepp_logan_filter_img;
	times = bench_for_execution_time(function, iterations, device, context, phantom_img, res, rots, scans);
	cout << right << "| CL_fast_shepp_logan_filter_img  | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_fast_cosine_filter_img;
	times = bench_for_execution_time(function, iterations, device, context, phantom_img, res, rots, scans);
	cout << right << "| CL_fast_cosine_filter_img       | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
		
	function = CL_discrete_back_projection_img;
	times = bench_for_execution_time(function, iterations, device, context, phantom_img, res, rots, scans);
	cout << right << "| CL_discrete_back_projection_img | " << setw(10) << times[0].count() << " | " << setw(8) << times[1].count() << " | " << setw(10) << times[2].count() << " | " << setw(2) << iterations << " |" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
}

void produce_images_img(vector<float>& phantom_img, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{	
	auto function = CL_compute_sinogram_img;
	vector<float> sinogram_img = run_function(function, device, context, phantom_img, res, rots, scans);
	cout << "Computed sinogram..." << endl;
		
	function = CL_fast_ram_lak_filter_img;
	vector<float> rlf_img = run_function(function, device, context, sinogram_img, res, rots, scans);
	cout << "Filtered sinogram with fast Ram-Lak filter..." << endl;
		
	function = CL_fast_shepp_logan_filter_img;
	vector<float> slf_img = run_function(function, device, context, sinogram_img, res, rots, scans);
	cout << "Filtered sinogram with fast Shepp-Logan filter..." << endl;
		
	function = CL_fast_cosine_filter_img;
	vector<float> cf_img = run_function(function, device, context, sinogram_img, res, rots, scans);
	cout << "Filtered sinogram with fast Cosine filter in ..." << endl;
		
	function = CL_discrete_back_projection_img; // Attention: Discrete back projection returns buffer, not image2d_t!
	vector<float> dbp = run_function(function, device, context, sinogram_img, res, rots, scans);
	cout << "Performed back projection of sinogram..." << endl;
		
	vector<float> dbp_rlf = run_function(function, device, context, rlf_img, res, rots, scans);
	cout << "Performed back projection of Ram-Lak filtered sinogram..." << endl;
		
	vector<float> dbp_slf = run_function(function, device, context, slf_img, res, rots, scans);
	cout << "Performed back projection of Shepp-Logan filtered sinogram..." << endl;

	vector<float> dbp_cf = run_function(function, device, context, cf_img, res, rots, scans);
	cout << "Performed back projection of Cosine filtered sinogram... " << endl; 
	
	vector<float> phantom = reduce_to_buffer(phantom_img);
	vector<float> sinogram = reduce_to_buffer(sinogram_img);
	vector<float> rlf = reduce_to_buffer(rlf_img);
	vector<float> slf = reduce_to_buffer(slf_img);
	vector<float> cf = reduce_to_buffer(cf_img);
	remove_artifacts(dbp_rlf, res);
	remove_artifacts(dbp_slf, res);
	remove_artifacts(dbp_cf, res);
	vector<float> err_dbp = absolute_value_of_matrix_difference(phantom, dbp);
	vector<float> err_dbp_rlf = absolute_value_of_matrix_difference(phantom, dbp_rlf);
	vector<float> err_dbp_slf = absolute_value_of_matrix_difference(phantom, dbp_slf);
	vector<float> err_dbp_cf = absolute_value_of_matrix_difference(phantom, dbp_cf);
	
	string outfile = "./Output/sinogram_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm(outfile, sinogram, scans, rots);
		
	outfile = "./Output/sinogram_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, rlf, scans, rots);
	outfile = "./Output/sinogram_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, slf, scans, rots);
	outfile = "./Output/sinogram_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, cf, scans, rots);
	
	
	outfile = "./Output/dbp_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp, res, res);
	outfile = "./Output/dbp_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_rlf, res, res);
	outfile = "./Output/dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_slf, res, res);
	outfile = "./Output/dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, dbp_cf, res, res);
	
	
	outfile = "./Output/err_dbp_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp, res, res);
	outfile = "./Output/err_dbp_rlf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_rlf, res, res);
	outfile = "./Output/err_dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_slf, res, res);
	outfile = "./Output/err_dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+".pgm";
	write_matrix_float_to_pgm_normalised(outfile, err_dbp_cf, res, res);
	
	cout << "Wrote results to disk." << endl;
}

void noisy_data_img(vector<float>& phantom_img, cl::Device device, cl::Context context, unsigned int res, unsigned int rots, unsigned int scans)
{
	float pi = 4*atan(1);
	float h = (float) 2/res;
	
	vector<float> sinogram_standard_img = CL_compute_sinogram_img(device, context, phantom_img, res, rots, scans);
	cout << "Computed sinogram..." << endl;
	
	vector<float> salt_and_pepper = salt_and_pepper_noise(res, 0.4);
	vector<float> salt_and_pepper_img = create_image2d_type(salt_and_pepper);
	vector<float> sinogram_img = add_matrices(sinogram_standard_img, salt_and_pepper_img);
	
	for(int i=0; i<3; i++)
	{
		vector<float> slf_img = CL_shepp_logan_filter_img(device, context, sinogram_img, pi/(3*(2*i+1)*h), res, rots, scans); 
		cout << "Computed Shepp-Logan filter..." << endl;
		vector<float> cf_img = CL_cosine_filter_img(device, context, sinogram_img, pi/(3*(2*i+1)*h), res, rots, scans); 
		cout << "Computed Cosine filter..." << endl;
		vector<float> dbp_slf = CL_discrete_back_projection_img(device, context, slf_img, res, rots, scans);
		cout << "Discrete back projection of Shepp-Logan filtered sinogram performed..." << endl;
		vector<float> dbp_cf = CL_discrete_back_projection_img(device, context, cf_img, res, rots, scans);
		cout << "Discrete back projection of Cosine filtered sinogram performed..." << endl;
	
		vector<float> slf = reduce_to_buffer(slf_img);
		vector<float> cf = reduce_to_buffer(cf_img);
	
		string outfile = "./Output/sinogram_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, slf, scans, rots);
		outfile = "./Output/sinogram_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, cf, scans, rots);
	
		remove_artifacts(dbp_slf, res);
		remove_artifacts(dbp_cf, res);
	
		outfile = "./Output/dbp_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, dbp_slf, res, res);
		outfile = "./Output/dbp_cf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, dbp_cf, res, res);
		cout << "Results written to disk." << endl;
		
		vector<float> difference = absolute_value_of_matrix_difference(dbp_slf, dbp_cf);
		outfile = "./Output/difference_cf_slf_"+to_string(res)+"_"+to_string(rots)+"_"+to_string(scans)+"_noise_"+to_string(i)+".pgm";
		write_matrix_float_to_pgm_normalised(outfile, difference, res, res);
	}
}


// --------------------------------------------------------------------------------------------------------------------------------

// CT functions

unsigned int set_resolution(unsigned int m, unsigned int n)
{
	if (m == n)
	{
		return m;
	}
	else 
	{
		cout << "Non-square phantoms not supported at this point, aborting" << endl;
		exit(-1);	
	}
}

vector<float> salt_and_pepper_noise(unsigned int res, float amp) // Expects amplitude between 0 and 1
{
	vector<float> image(res*res, 0);
	
	random_device dev;
    default_random_engine rng(dev());
    uniform_int_distribution<int> dist(-127,127);
	
	for(int i=0; i<res; i++)
	{
		for(int j=0; j<res; j++)
		{
			image[i*res+j] = amp*dist(rng);
		}
	}
	
	return image;
}

// --------------------------------------------------------------------------------------------------------------------------------

vector<float> add_matrices(vector<float>& A, vector<float>& B)
{	
	if (A.size() == B.size())
	{
		vector<float> C(A.size(), 0.0);
		
		for(int i=0; i<A.size(); i++)
		{
			C[i] = A[i]+B[i];
		}
		
		return C;
	}
	else 
	{
		cout << "Can't add matrices that aren't the same size!" << endl;	
		exit(-1);
	}
}
vector<float> subtract_matrices(vector<float>& A, vector<float>& B)
{
	if (A.size() == B.size())
	{
		vector<float> C(A.size(), 0.0);
		
		for(int i=0; i<A.size(); i++)
		{
			C[i] = A[i] - B[i];
		}
		
		return C;
	}
	else 
	{
		cout << "Can't subtract matrices that aren't the same size!" << endl;
		exit(-1);	
	}
}

vector<float> absolute_value_of_matrix_difference(vector<float>& A, vector<float>& B)
{
	if (A.size() == B.size())
	{
		vector<float> C(A.size(), 0.0);
		
		for(int i=0; i<A.size(); i++)
		{
			C[i] = fabs(A[i] - B[i]);
		}
		
		return C;
	}
	else 
	{
		cout << "Can't subtract matrices that aren't the same size!" << endl;
		exit(-1);	
	}
}

// --------------------------------------------------------------------------------------------------------------------------------

// Input reading and output writing

bool try_reading_float(string& input, float& output)
{
	try
	{
		output = stof(input);
	}
	catch(invalid_argument)
	{
		return false;
	}
	return true;
}

bool try_reading_uint(string& input, unsigned int& output)
{
	try
	{
		output = stoul(input);
	}
	catch(invalid_argument)
	{
		return false;
	}
	return true;
}

void split_string(string& input, vector<string>& output)
{
	stringstream ss(input);       // Insert the string into a stream
	string buffer;
    while (ss >> buffer)
	{
		output.push_back(buffer);
	}
}

vector<float> read_matrix_float(string filename, unsigned int& m, unsigned int& n)
{
	vector<float> matrix;
	
	vector<string> dimensions_string;
	vector<unsigned int> dimensions(2);
	vector<string> line_values_string;
	vector<float> line_values;
	float tmp;
	string input_buffer;
	
	ifstream data_file(filename);
	if(!data_file.is_open())
	{
		cout << "File couln't be opened!" << endl;
		exit(-1);
	}
	
	// Read first line and check for compatibility
	getline(data_file, input_buffer);
	split_string(input_buffer, dimensions_string);
	if (dimensions_string.size() == 2)
	{
		if(try_reading_uint(dimensions_string[0],dimensions[0]) and try_reading_uint(dimensions_string[1], dimensions[1]))
		{
			m = dimensions[0];
			n = dimensions[1];
			for(int i=0; i<m; i++)
			{
				getline(data_file, input_buffer);
				split_string(input_buffer, line_values_string);
				if(line_values_string.size()==n)
				{
					for(int k=0; k<n; k++)
					{
						if (try_reading_float(line_values_string[k], tmp))
						{
							line_values.push_back(tmp);
						}
						else 
						{
							cout << "File does not meet requirements!" << endl;
							exit(-1);
						}
					}
					matrix.insert(matrix.end(),line_values.begin(), line_values.end());
					
					// Empty buffers!
					
					input_buffer.clear();
					line_values_string.clear();
					line_values.clear();
				}
				else 
				{
					cout << "File does not meet requirements!" << endl;
					exit(-1);	
				}
			}
			return matrix;
		}
		else 
		{
			cout << "File does not meet requirements!" << endl;
			exit(-1);
		}
	}	
	else 
	{
		cout << "File does not meet requirements!" << endl;
		exit(-1);
	}
}

void print_matrix_float(vector<float> matrix, const unsigned int& m, const unsigned int& n)
{
	if (matrix.size() != m*n)
	{
		cout << "Matrix size: " << matrix.size() << ", Dimension: "<<m<<"*"<<n<<"="<<m*n<<endl;
		cout << "Corrupt matrix!" << endl;
		exit(-1);
	}
	else 
	{
		for(int i=0; i<m; i++)
		{
			for(int j=0; j<n; j++)
			{
				cout << fixed;
				cout.precision(3);
				cout << setw(10) << matrix[i*n+j]; 
			}
			cout << endl;
		}	
	}
}

void write_matrix_float_to_file(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n)
{
	if (matrix.size() != m*n)
	{
		cout << "Attempted to write corrupt matrix to file " << filename << ", aborting!" << endl;
		exit(-1);
	}
	
	else 
	{
		ofstream output_file(filename);
		if (output_file.is_open())
		{
			for(int i=0; i<m; i++)
			{
				for(int j=0; j<n; j++)
				{
					output_file << fixed;
					output_file.precision(3);
					output_file << setw(10) << matrix[i*n+j]; 
				}
				output_file << endl;
			}	 
		}
		else 
		{
			cout << "Couldn't create file!" << endl;
			exit(-1);	
		}
	}	
}

void write_matrix_float_to_pgm(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n) // m = rows of matrix, n = columns of matrix
{
	// Expects matrix with float values in the range of 0 and 255. Conversion necessary for matrices with different gray value spectra
	
	float conversion; // Dummy variable that is converted to unsigned char and clipped to 0..255
	unsigned char output_pixel;
	
	if (matrix.size() != m*n)
	{
		cout << "Attempted to write corrupt matrix to " << filename << ", aborting!" << endl;
		exit(-1);
	}
	
	ofstream output_file(filename, ios::out | ios::binary);
	if (output_file.is_open())
	{
		output_file << "P5" << endl;
		output_file << n << " " << m << endl; // Switch n and m for usual resolution statement of picture
		output_file << "255" << endl; // States maximum grey value
		
		for (int i=0; i<m; i++)
		{
			for (int j=0; j<n; j++)
			{
				conversion = matrix[i*n+j] +0.5; // For rounding
				if (conversion < 0)
				{
					output_pixel = (unsigned char) 0;
					output_file << output_pixel; 
				}
				if (conversion > 255)
				{
					output_pixel= (unsigned char) 255;
					output_file << output_pixel;
				}
				else 
				{
					output_pixel = (unsigned char) conversion; 
					output_file << output_pixel;
				}
				
			}
			// output_file << endl; // Terminate pixel row 
		}
		
	}
	else 
	{
		cout << "Couldn't create file!" << endl;
		exit(-1);
	}
}

void write_matrix_float_to_pgm_normalised(string filename, vector<float> matrix, const unsigned int& m, const unsigned int& n) // m = rows of matrix, n = columns of matrix
{
	// Expects matrix with float values in the range of 0 and 255. Conversion necessary for matrices with different gray value spectra
	
	float min,max,conversion,scale; // Dummy variable that is converted to unsigned char and clipped to 0..255
	vector<float> output(m*n, 0);
	unsigned char output_pixel;
	
	if (matrix.size() != m*n)
	{
		cout << "Attempted to write corrupt matrix to " << filename << ", aborting!" << endl;
		exit(-1);
	}
	
	min = matrix[0]; // Initialise to value that actually is in the image
	max = matrix[0];
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<n; j++)
		{
			if (matrix[i*n+j] > max)
			{
				max = matrix[i*n+j];
			}
			if (matrix[i*n+j] < min)
			{
				min = matrix[i*n+j];
			}
		}
	}
	
	// Normalise to {0,...,255}
	
	scale = 255/(max - min);
	
	for(int i=0; i<m; i++)
	{
		for(int j=0; j<m; j++)
		{
			output[i*m+j] = scale*(matrix[i*m+j]-min);
		}
	}
	
	ofstream output_file(filename, ios::out | ios::binary);
	if (output_file.is_open())
	{
		output_file << "P5" << endl;
		output_file << n << " " << m << endl; // Switch n and m for usual resolution statement of picture
		output_file << "255" << endl; // States maximum grey value
		
		for (int i=0; i<m; i++)
		{
			for (int j=0; j<n; j++)
			{
				conversion = output[i*n+j] +0.5; // For rounding
				if (conversion > 255)
				{
					output_pixel= (unsigned char) 255;
					output_file << output_pixel;
				}
				else 
				{
					output_pixel = (unsigned char) conversion; 
					output_file << output_pixel;
				}
			}
		}
	}
	else 
	{
		cout << "Couldn't create file!" << endl;
		exit(-1);
	}
}

vector<float> read_pgm_to_matrix_float(string filename, unsigned int& m, unsigned int& n)
{
	string input_line;
	vector<string> line_values_string;
	vector<float> matrix;
	unsigned char* tmp;
	float dummy;
	
	ifstream input_file(filename, ios::binary);
	if (input_file.is_open())
	{
		getline(input_file, input_line);
		if(input_line.compare("P5") != 0)
		{
			cout << "Unknown file format in file " << filename << endl;
			exit(-1);
		}
		else 
		{
			getline(input_file, input_line);
			while(input_line.compare(0,1,"#")==0)
			{	
				input_line.clear(); // Line read was comment, discard
				getline(input_file, input_line);
			}	
			split_string(input_line, line_values_string);
			if (line_values_string.size()==2)
			{
				if(try_reading_uint(line_values_string[0], m) and try_reading_uint(line_values_string[1], n))
				{
					getline(input_file, input_line); // Read maximum grey value and discard
					input_line.clear();
						
					tmp = (unsigned char*) new unsigned char[m*n];
							
					for(int i=0; i<m*n; i++)
					{
						input_file.read(reinterpret_cast<char*>(tmp), m*n*sizeof(unsigned char));
					}
				
					for(int i=0; i<m; i++)
					{
						for(int j=0; j<n; j++)
						{
							dummy = (float) tmp[i*n+j];
							matrix.push_back(dummy);
						}
					}
				}
				else 
				{
					cout << "Corrupt file " << filename << endl;	
					exit(-1);
				}	
			}
			else 
			{
				cout << "Corrput file " << filename << endl;
				exit(-1);	
			}
		}
	}		
	else 
	{
		cout << "Couldn't open file " << filename << endl;
		exit(-1);	
	}
	return matrix;
}

//-------------------------------------------------------------------------------------
// Phantom
//-------------------------------------------------------------------------------------

void raster_ellipse(vector<float>& image, int res, vector<float> focus, float semimajor, float semiminor, float gray_value)
{
	float h = (float) 2/res;
	float x, y;

	if (focus.size() == 2)
	{
		x = focus[0];
		y = focus[1];
	}
	else
	{
		cout << "Corrupt function call in raster_ellipsis." << endl;
		exit(-1);
	}

	float semimajor2 = semimajor*semimajor;
	float semiminor2 = semiminor*semiminor;

	float tmp;
	float x_tmp = -1 + (h / 2), y_tmp = 1 - (h / 2);

	for(int i = 1; i < res - 1; i++)
	{
		for(int j = 1; j < res - 1; j++)
		{
			tmp = (float) (x_tmp - x)*(x_tmp - x)/semimajor2 + (y_tmp - y)*(y_tmp - y)/semiminor2;
			if (1 - tmp > 0)
			{
				image[j*res+i] += gray_value;
			}
			y_tmp -= h;
		}
		y_tmp = 1-(h/2);
		x_tmp += h;
	}
}

void raster_ellipse_rotated(vector<float>& image, int res, vector<float> focus, float a, float b, float gray_value, float angle)
{
	float h = (float) 2/res;
	float x, y;

	if (focus.size() == 2)
	{
		x = focus[0];
		y = focus[1];
	}
	else
	{
		cout << "Corrupt function call in raster_ellipsis." << endl;
		exit(-1);
	}
 
	float sinw = sin(angle);
	float cosw = cos(angle);

	float tmp;
	float x_tmp = -1 + (h / 2), y_tmp = 1 - (h / 2);

	for(int i = 1; i < res - 1; i++)
	{
		for(int j = 1; j < res - 1; j++)
		{
			tmp = ((x_tmp-x)*cosw + (y_tmp-y)*sinw)*((x_tmp-x)*cosw + (y_tmp-y)*sinw)/(a*a) + ((x_tmp-x)*sinw - (y_tmp-y)*cosw)*((x_tmp-x)*sinw - (y_tmp-y)*cosw)/(b*b);
			if (1 - tmp > 0)
			{
				image[j*res+i] += gray_value;
			}
			y_tmp -= h;
		}
		y_tmp = 1-(h/2);
		x_tmp += h;
	}
}

vector<float> raster_shepp_logan(unsigned int res)
{
	vector<float> phantom(res*res, 0);
	vector<float> focus(2, 0.0);
	focus[0] = 0;
	focus[1] = 0;
	raster_ellipse(phantom, res, focus, 0.69, 0.92, 255);
	focus[0] = 0;
	focus[1] = -0.0184;
	raster_ellipse(phantom, res, focus, 0.6624, 0.874, -203);
	focus[0] = 0.22;
	focus[1] = 0;
	raster_ellipse_rotated(phantom, res, focus, 0.11, 0.31, -52, -0.31);
	focus[0] = -0.22;
	focus[1] = 0;
	raster_ellipse_rotated(phantom, res, focus, 0.16, 0.41, -52, 0.31);
	focus[0] = 0;
	focus[1] = 0.35;
	raster_ellipse(phantom, res, focus, 0.21, 0.25, 25);
	focus[0] = 0;
	focus[1] = 0.1;
	raster_ellipse(phantom, res, focus, 0.046, 0.046, 25);
	focus[0] = 0;
	focus[1] = -0.1;
	raster_ellipse(phantom, res, focus, 0.046, 0.046, 25);
	focus[0] = -0.08;
	focus[1] = -0.605;
	raster_ellipse(phantom, res, focus, 0.046, 0.023, 25);
	focus[0] = 0;
	focus[1] = -0.605;
	raster_ellipse(phantom, res, focus, 0.023, 0.023, 25);
	focus[0] = 0.06;
	focus[1] = -0.605;
	raster_ellipse(phantom, res, focus, 0.023, 0.046, 25);
	
	return phantom;
}
